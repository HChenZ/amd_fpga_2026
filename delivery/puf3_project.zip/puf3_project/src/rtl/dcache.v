`timescale 1ns / 1ps

module dcache #(
    parameter XLEN = 32,
    parameter DCACHE_SET_SIZE = 64,
    parameter DCACHE_LINE_WORDS = 4
)(
    input                   clk,
    input                   rst_n,

    // ========== CPU 接口（来自 ex_stage，送到 mem_stage） ==========
    input       [XLEN-1:0]  cpu_addr_i,
    input       [XLEN-1:0]  cpu_wdata_i,
    input       [XLEN/8-1:0]cpu_wmask_i,
    input                   cpu_re_i,
    input                   cpu_we_i,
    input                   cpu_req_stall_i,
    output      [XLEN-1:0]  cpu_rdata_o,
    output                  cpu_stall_o,

    // ========== Bus 接口（直连 bus_interconnect） ==========
    output      [XLEN-1:0]  bus_addr_o,
    output                  bus_mem_re_o,
    output                  bus_mem_we_o,
    output                  bus_mmio_re_o,
    output                  bus_mmio_we_o,
    output      [XLEN/8-1:0]bus_wmask_o,
    output      [XLEN-1:0]  bus_wdata_o,
    output                  bus_load_miss_o,
    output                  bus_store_miss_o,
    input       [XLEN-1:0]  bus_rdata_i,
    input                   bus_rdata_valid_i

);

    // =========================================================================
    // 参数计算
    // =========================================================================
    localparam BOFF_WIDTH   = $clog2(XLEN/8);
    localparam INDEX_WIDTH  = $clog2(DCACHE_SET_SIZE);
    localparam WOFF_WIDTH   = $clog2(DCACHE_LINE_WORDS);
    localparam TAG_WIDTH    = XLEN - INDEX_WIDTH - WOFF_WIDTH - BOFF_WIDTH;
    localparam WDATA_W      = INDEX_WIDTH + WOFF_WIDTH;

    // =========================================================================
    // 地址分解 & 可缓存判断
    // =========================================================================
    wire [TAG_WIDTH-1:0]   req_tag  = cpu_addr_i[XLEN-1:INDEX_WIDTH+WOFF_WIDTH+BOFF_WIDTH];
    wire [INDEX_WIDTH-1:0] req_idx  = cpu_addr_i[INDEX_WIDTH+WOFF_WIDTH+BOFF_WIDTH-1:WOFF_WIDTH+BOFF_WIDTH];
    wire [WOFF_WIDTH-1:0]  req_woff = cpu_addr_i[WOFF_WIDTH+BOFF_WIDTH-1:BOFF_WIDTH];

    wire cacheable = (cpu_addr_i[31:20] == 12'h100);

    // =========================================================================
    // Way0 / Way1 Tag 存储（分布式 RAM，异步读）
    // =========================================================================
    (* ram_style = "distributed" *)
    reg [TAG_WIDTH-1:0] tag_way0 [0:DCACHE_SET_SIZE-1];
    (* ram_style = "distributed" *)
    reg [TAG_WIDTH-1:0] tag_way1 [0:DCACHE_SET_SIZE-1];

    wire [TAG_WIDTH-1:0] tag_way0_out = tag_way0[req_idx];
    wire [TAG_WIDTH-1:0] tag_way1_out = tag_way1[req_idx];

    // =========================================================================
    // Data 存储
    // =========================================================================
    (* ram_style = "block" *) reg [XLEN-1:0] data_way0 [0:(1<<WDATA_W)-1];
    (* ram_style = "block" *) reg [XLEN-1:0] data_way1 [0:(1<<WDATA_W)-1];
    reg [XLEN-1:0] data_way0_out;
    reg [XLEN-1:0] data_way1_out;

    // =========================================================================
    // Valid 位 & LRU 位
    // =========================================================================
    reg [DCACHE_SET_SIZE-1:0] valid_way0;
    reg [DCACHE_SET_SIZE-1:0] valid_way1;
    reg [DCACHE_SET_SIZE-1:0] lru;

    // =========================================================================
    // Tag 比较 & Hit 判断
    // =========================================================================
    wire hit_way0 = cacheable && valid_way0[req_idx] && (tag_way0_out == req_tag);
    wire hit_way1 = cacheable && valid_way1[req_idx] && (tag_way1_out == req_tag);
    wire hit = hit_way0 || hit_way1;

    reg hit_way0_r, hit_way1_r;

    // =========================================================================
    // 替换策略
    // =========================================================================
    wire way0_invalid = ~valid_way0[req_idx];
    wire way1_invalid = ~valid_way1[req_idx];
    wire victim_way = way0_invalid ? 1'b0 :
                      way1_invalid ? 1'b1 :
                      lru[req_idx];

    // =========================================================================
    // Only cacheable load misses use the extra request pipeline stage.
    // =========================================================================
    localparam IDLE         = 3'd0;
    localparam MISS_CAPTURE = 3'd1;  // NEW: Capture miss info for one cycle
    localparam FILL         = 3'd2;

    reg [2:0] state;
    reg [2:0] next_state;
    reg [2:0] fill_cnt;

    // Registered request bundle
    reg [XLEN-1:0]      bus_addr_r;
    reg [XLEN-1:0]      bus_wdata_r;
    reg [XLEN/8-1:0]    bus_wmask_r;
    reg                 bus_mem_re_r;
    reg                 bus_mem_we_r;
    reg                 bus_mmio_re_r;
    reg                 bus_mmio_we_r;
    reg                 bus_load_miss_r;
    reg                 bus_store_miss_r;

    wire cache_access_fire = (state == IDLE) && !cpu_req_stall_i;
    wire mmio_access_fire = cache_access_fire;

    // =========================================================================
    // Miss 地址锁存
    // =========================================================================
    reg [TAG_WIDTH-1:0]   miss_tag;
    reg [INDEX_WIDTH-1:0] miss_idx;
    reg [WOFF_WIDTH-1:0]  miss_woff;
    reg                   miss_way;

    // Request bundle captured in IDLE, consumed in MISS_CAPTURE
    reg [XLEN-1:0]      captured_addr;
    reg [XLEN-1:0]      captured_wdata;
    reg [XLEN/8-1:0]    captured_wmask;

    // Latched classification: MISS_CAPTURE must never inspect live hit/address.
    reg                 cap_load_miss_q;

    // =========================================================================
    // BRAM 读写地址
    // =========================================================================
    wire [WDATA_W-1:0]   rd_addr = {req_idx, req_woff};
    wire [1:0] wr_word = miss_woff + fill_cnt[1:0];
    wire [WDATA_W-1:0] fill_wr_addr = {miss_idx, wr_word};

    // =========================================================================
    // 写使能和控制信号
    // =========================================================================
    wire fill_we = (state == FILL) && bus_rdata_valid_i;
    wire fill_way0_we = fill_we && (miss_way == 0);
    wire fill_way1_we = fill_we && (miss_way == 1);

    wire load_miss_now = cache_access_fire && cpu_re_i && cacheable && !hit;
    wire store_now = cache_access_fire && cpu_we_i && cacheable;
    wire store_cache_write = store_now;
    wire mmio_read_now = mmio_access_fire && cpu_re_i && !cacheable;
    wire mmio_write_now = mmio_access_fire && cpu_we_i && !cacheable;
    wire store_miss = store_now && !hit;

    wire load_miss = load_miss_now;
    reg  load_miss_reg;

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
            load_miss_reg <= 1'b0;
        else
            load_miss_reg <= load_miss;
    end

    // FILL 期间直接抓取第一个字
    reg [XLEN-1:0] fill_capture_data;

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
            fill_capture_data <= {XLEN{1'b0}};
        else if (fill_we && fill_cnt == 3'd0)
            fill_capture_data <= bus_rdata_i;
    end

    reg fill_done_r;

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
            fill_done_r <= 1'b0;
        else
            fill_done_r <= (state == FILL) && (fill_cnt == 3'd3) && bus_rdata_valid_i;
    end

    // =========================================================================
    // AGGRESSIVE PIPELINE: Capture request in MISS_CAPTURE state
    // =========================================================================
    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            captured_addr  <= {XLEN{1'b0}};
            captured_wdata <= {XLEN{1'b0}};
            captured_wmask <= {(XLEN/8){1'b0}};
        end
        else if (load_miss_now)
        begin
            captured_addr  <= cpu_addr_i;
            captured_wdata <= cpu_wdata_i;
            captured_wmask <= cpu_wmask_i;
        end
    end

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            cap_load_miss_q  <= 1'b0;
        end
        else
        begin
            cap_load_miss_q  <= load_miss_now;
        end
    end

    wire in_capture = (state == MISS_CAPTURE);

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            miss_tag  <= {TAG_WIDTH{1'b0}};
            miss_idx  <= {INDEX_WIDTH{1'b0}};
            miss_woff <= {WOFF_WIDTH{1'b0}};
            miss_way  <= 1'b0;
        end
        else if (load_miss_now)
        begin
            miss_tag  <= req_tag;
            miss_idx  <= req_idx;
            miss_woff <= req_woff;
            miss_way  <= victim_way;
        end
    end

    // =========================================================================
    // MMIO read: fixed latency, no valid from bus_interconnect.
    // T   IDLE, mmio_read_now
    // T+1 bus_mmio_re_o=1, mmio_read_wait_r=1 (stall)
    // T+2 peripheral data on bus_rdata_i, uncached_req_r=1, stall released
    // =========================================================================
    reg uncached_req_r;
    reg mmio_read_wait_r;

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            uncached_req_r   <= 1'b0;
            mmio_read_wait_r <= 1'b0;
        end
        else
        begin
            mmio_read_wait_r <= mmio_read_now;
            uncached_req_r   <= mmio_read_wait_r;
        end
    end

    // =========================================================================
    // BRAM 读写
    // =========================================================================
    wire [XLEN-1:0] data_out = hit_way0_r ? data_way0_out : data_way1_out;

    // =========================================================================
    // TIMING C：1 项 store buffer + 元数据更新寄存化
    //
    // 改前：store 那一拍直接用 cpu_wdata_i/字节掩码写 data_way0/1 的 BRAM 写口，
    // 并在同一拍用 hit_way0/hit_way1 清掉另一路 valid、用 hit 更新 LRU。于是
    // 「store 数据（来自 EX 旁路 mux）→ BRAM WEA」和「请求地址 → tag RAM → hit
    // → valid_way/lru 的 D 端」都必须在一拍内走完（F 之后 192 条、worst −0.072）。
    //
    // 改法：本拍只把 {地址,数据,字节掩码} 打进 1 项 buffer，下一拍写 BRAM；
    // valid/lru 的"要做什么"在请求当拍算好、寄存一拍再作用。BRAM 写口与元数据
    // D 端因此只由本地寄存器驱动。可见性由 buffer → load 的定向转发保证。
    // =========================================================================
    wire                 sb_capture = store_now;
    reg                  sb_valid;
    reg  [WDATA_W-1:0]   sb_addr;
    reg  [XLEN-1:0]      sb_wdata;
    reg  [XLEN/8-1:0]    sb_wmask;

    wire sb_commit = sb_valid;          // 捕获后恰好一拍提交
    // 元数据更新记录（valid / LRU 的一拍延迟版本）
    reg                    upd_load_miss;
    reg                    upd_store;
    reg                    upd_hit0;
    reg                    upd_hit1;
    reg                    upd_acc;
    reg                    upd_victim;
    reg  [INDEX_WIDTH-1:0] upd_idx;

    reg               sb_fwd_hit_r;
    reg  [XLEN-1:0]   sb_fwd_data_r;
    reg  [XLEN/8-1:0] sb_fwd_mask_r;

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            sb_valid <= 1'b0;
            sb_addr  <= {WDATA_W{1'b0}};
            sb_wdata <= {XLEN{1'b0}};
            sb_wmask <= {(XLEN/8){1'b0}};
        end
        else
        begin
            sb_valid <= sb_capture;
            sb_addr  <= rd_addr;
            sb_wdata <= cpu_wdata_i;
            sb_wmask <= cpu_wmask_i;
        end
    end

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            upd_load_miss <= 1'b0;
            upd_store     <= 1'b0;
            upd_hit0      <= 1'b0;
            upd_hit1      <= 1'b0;
            upd_acc       <= 1'b0;
            upd_victim    <= 1'b0;
            upd_idx       <= {INDEX_WIDTH{1'b0}};
        end
        else
        begin
            upd_load_miss <= load_miss_now;
            upd_store     <= store_now;
            upd_hit0      <= hit_way0;
            upd_hit1      <= hit_way1;
            upd_acc       <= cache_access_fire && hit && (cpu_re_i || cpu_we_i);
            upd_victim    <= victim_way;
            upd_idx       <= req_idx;
        end
    end

    // store → load 定向转发：同字地址按字节掩码覆盖读出的旧值
    wire sb_fwd_hit = sb_valid && (sb_addr == rd_addr);

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            sb_fwd_hit_r  <= 1'b0;
            sb_fwd_data_r <= {XLEN{1'b0}};
            sb_fwd_mask_r <= {(XLEN/8){1'b0}};
        end
        else
        begin
            sb_fwd_hit_r  <= sb_fwd_hit;
            sb_fwd_data_r <= sb_wdata;
            sb_fwd_mask_r <= sb_wmask;
        end
    end



    integer fwd_byte_i;
    reg [XLEN-1:0] data_out_fwd;
    always @(*)
    begin
        data_out_fwd = data_out;
        if (sb_fwd_hit_r)
            for (fwd_byte_i = 0; fwd_byte_i < XLEN/8; fwd_byte_i = fwd_byte_i + 1)
                if (sb_fwd_mask_r[fwd_byte_i])
                    data_out_fwd[fwd_byte_i*8 +: 8] = sb_fwd_data_r[fwd_byte_i*8 +: 8];
    end

    assign cpu_rdata_o = uncached_req_r  ? bus_rdata_i :
                         fill_done_r     ? fill_capture_data :
                                          data_out_fwd;

    // Stall includes new MISS_CAPTURE state
    assign cpu_stall_o = (state != IDLE) || load_miss_reg || mmio_read_wait_r;

    // Way0 Port A: 只读（SDP 的读口）
    always @(posedge clk)
        data_way0_out <= data_way0[rd_addr];

    // Way0 Port B: fill 与 store buffer 提交共用写口
    // fill 与 sb_commit 不可能同拍：store 只可能在 IDLE 发起、提交在下一拍，
    // 而 FILL 期间 CPU 被 stall，MISS_CAPTURE 至少隔一拍。
    integer way0_cpu_byte_i;
    always @(posedge clk)
    begin
        if (fill_way0_we)
            data_way0[fill_wr_addr] <= bus_rdata_i;
        else if (sb_commit)
        begin
            for (way0_cpu_byte_i = 0; way0_cpu_byte_i < XLEN/8; way0_cpu_byte_i = way0_cpu_byte_i + 1)
            begin
                if (sb_wmask[way0_cpu_byte_i])
                    data_way0[sb_addr][way0_cpu_byte_i*8 +: 8] <= sb_wdata[way0_cpu_byte_i*8 +: 8];
            end
        end
    end

    // Way1 Port A: 只读（SDP 的读口）
    always @(posedge clk)
        data_way1_out <= data_way1[rd_addr];

    // Way1 Port B: fill 与 store buffer 提交共用写口
    integer way1_cpu_byte_i;
    always @(posedge clk)
    begin
        if (fill_way1_we)
            data_way1[fill_wr_addr] <= bus_rdata_i;
        else if (sb_commit)
        begin
            for (way1_cpu_byte_i = 0; way1_cpu_byte_i < XLEN/8; way1_cpu_byte_i = way1_cpu_byte_i + 1)
            begin
                if (sb_wmask[way1_cpu_byte_i])
                    data_way1[sb_addr][way1_cpu_byte_i*8 +: 8] <= sb_wdata[way1_cpu_byte_i*8 +: 8];
            end
        end
    end

    // hit_way0/hit_way1 寄存
    always @(posedge clk)
    begin
        hit_way0_r <= hit_way0;
        hit_way1_r <= hit_way1;
    end

    // =========================================================================
    // FSM 次态逻辑 - AGGRESSIVE PIPELINE VERSION
    // 强制在MISS_CAPTURE状态停留一个周期
    // =========================================================================
    always @(*) begin
        case (state)
            IDLE: begin
                if (load_miss_now)
                    next_state = MISS_CAPTURE;  // NEW: Go to capture state first
                else
                    next_state = IDLE;
            end

            MISS_CAPTURE: begin
                if (cap_load_miss_q)
                    next_state = FILL;          // Load miss -> FILL
                else
                    next_state = IDLE;          // Store/MMIO -> back to IDLE
            end

            FILL: begin
                if (fill_cnt == 3'd3 && bus_rdata_valid_i)
                    next_state = IDLE;
                else
                    next_state = FILL;
            end

            default: next_state = IDLE;
        endcase
    end

    // =========================================================================
    // FSM 状态寄存
    // =========================================================================
    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
            state <= IDLE;
        else
            state <= next_state;
    end

    // =========================================================================
    // Fill 计数器
    // =========================================================================
    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
            fill_cnt <= 3'd0;
        else if (state == IDLE)
            fill_cnt <= 3'd0;
        else if(fill_we)
            fill_cnt <= fill_cnt + 1'd1;
    end

    // =========================================================================
    // 外部 MEM 接口控制 - Use captured signals in MISS_CAPTURE state
    // =========================================================================
    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            bus_addr_r          <= {XLEN{1'b0}};
            bus_wdata_r         <= {XLEN{1'b0}};
            bus_wmask_r         <= {(XLEN/8){1'b0}};
        end
        else if (in_capture)
        begin
            bus_addr_r  <= captured_addr;
            bus_wdata_r <= captured_wdata;
            bus_wmask_r <= captured_wmask;
        end
        else if (store_now || mmio_read_now || mmio_write_now)
        begin
            bus_addr_r  <= cpu_addr_i;
            bus_wdata_r <= cpu_wdata_i;
            bus_wmask_r <= cpu_wmask_i;
        end
    end

    // Single-cycle strobes. Stores/MMIO bypass MISS_CAPTURE (HEAD latency).
    // bus_interconnect latches mem_re itself; a held strobe would queue a
    // second read burst (dcache_re_buf) during FILL.
    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            bus_mem_re_r     <= 1'b0;
            bus_mem_we_r     <= 1'b0;
            bus_load_miss_r  <= 1'b0;
            bus_store_miss_r <= 1'b0;
            bus_mmio_re_r    <= 1'b0;
            bus_mmio_we_r    <= 1'b0;
        end
        else
        begin
            bus_mem_re_r     <= in_capture && cap_load_miss_q;
            bus_mem_we_r     <= store_now;
            bus_load_miss_r  <= in_capture && cap_load_miss_q;
            bus_store_miss_r <= store_miss;
            bus_mmio_re_r    <= mmio_read_now;
            bus_mmio_we_r    <= mmio_write_now;
        end
    end

    assign bus_addr_o = bus_addr_r;
    assign bus_mem_re_o = bus_mem_re_r;
    assign bus_mem_we_o = bus_mem_we_r;
    assign bus_mmio_re_o = bus_mmio_re_r;
    assign bus_mmio_we_o = bus_mmio_we_r;
    assign bus_wmask_o = bus_wmask_r;
    assign bus_wdata_o = bus_wdata_r;
    assign bus_load_miss_o = bus_load_miss_r;
    assign bus_store_miss_o = bus_store_miss_r;

    // =========================================================================
    // Tag 写
    // =========================================================================
    always @(posedge clk)
    begin
        if (fill_we && fill_cnt == 3'd3 && (miss_way == 0))
            tag_way0[miss_idx] <= miss_tag;
    end

    always @(posedge clk)
    begin
        if (fill_we && fill_cnt == 3'd3 && (miss_way == 1))
            tag_way1[miss_idx] <= miss_tag;
    end

    // =========================================================================
    // Valid / LRU 更新
    // =========================================================================
    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            valid_way0 <= {DCACHE_SET_SIZE{1'b0}};
            valid_way1 <= {DCACHE_SET_SIZE{1'b0}};
            lru        <= {DCACHE_SET_SIZE{1'b0}};
        end
        else
        begin
            if (upd_load_miss)
            begin
                if (upd_victim == 1'b0)
                    valid_way0[upd_idx] <= 1'b0;
                else
                    valid_way1[upd_idx] <= 1'b0;
            end

            if (upd_store)
            begin
                if (upd_hit0)
                    valid_way1[upd_idx] <= 1'b0;
                else if (upd_hit1)
                    valid_way0[upd_idx] <= 1'b0;
                else
                begin
                    valid_way0[upd_idx] <= 1'b0;
                    valid_way1[upd_idx] <= 1'b0;
                end
            end

            if (fill_we && fill_cnt == 3'd3)
            begin
                if (miss_way == 0)
                    valid_way0[miss_idx] <= 1'b1;
                else
                    valid_way1[miss_idx] <= 1'b1;
                lru[miss_idx] <= ~miss_way;
            end

            if (upd_acc)
                lru[upd_idx] <= upd_hit0;
        end
    end

endmodule
