# Current PUF3 source project

This package contains the RV32 five-stage CPU, Ascon SW/MMIO/ISE and PUF v1/DNA source,
firmware, IP configurations, timing hooks, host libraries, vectors and the PUF3 Notebook.
Start with [build instructions](build/readme.md), [board entry](board/readme.md),
[Notebook guide](src/pynq_puf3/readme.md) and [source manifest](source_manifest.json).

Vivado2025.2 / xc7z020clg400-1 / pynq_puf3_wrapper / PQF3=0x33465150 / pynq-svc-puf3.
Use the board-local soc_top.v and key_mmio.v variants through the dedicated build Tcl; do not import all RTL blindly.
See [source-only boundaries](source_package.md): no prebuilt overlay or evidence bundle is included.
A Git checkout or a new local Git commit is required by the existing Vivado provenance queries.
The six small archived timing files are host-test fixtures, not new performance measurements.
The independent Skill, historical projects, report, full project board and raw records are separate in the full repository.
Repository maintenance tools package_delivery.py, verify_delivery.py and restore_records.py require the full repository, not this source-only ZIP.
Preserve LICENSE and file-level notices. PUF cross-power/PVT/reliability and RO-counter timing are not signed off.
