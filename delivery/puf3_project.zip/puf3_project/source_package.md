# Current PUF3 source package

This is source/configuration, not a prebuilt overlay or evidence bundle.
Install Vivado2025.2, Icarus and an RV32IM_Zicsr cross compiler. Build from a Git checkout, or initialize
a local Git repository/commit after extraction: the unchanged Tcl/package scripts query Git for provenance.
The source_manifest identifies the actual archived source revision and byte hashes. A new local commit is not that original revision.
Start at src/pynq_puf3/readme.md and build/readme.md. The historical artifact manifest is reference only;
rebuilding does not prove a fresh bit has passed the archived board test.
