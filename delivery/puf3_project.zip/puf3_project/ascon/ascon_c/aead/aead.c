#include "api.h"
#include "ascon.h"
// #include "crypto_aead.h"
#include "permutations.h"
#include "printstate.h"
#include "word.h"

/* Best-effort compiler-retained wipe of software-owned objects, not a claim
 * about physical registers, caches, interrupts, or side-channel resistance. */
static void ascon_clear(void *ptr, unsigned long long n)
{
  volatile unsigned char *p = (volatile unsigned char *)ptr;
  while (n--) *p++ = 0;
}

int crypto_aead_encrypt(unsigned char *c, unsigned long long *clen,
                        const unsigned char *m, unsigned long long mlen,
                        const unsigned char *ad, unsigned long long adlen,
                        const unsigned char *nsec, const unsigned char *npub,
                        const unsigned char *k)
{
  (void)nsec;

  /* set ciphertext size */
  *clen = mlen + CRYPTO_ABYTES;

  /* print input bytes */
  print("encrypt\n");
  printbytes("k", k, CRYPTO_KEYBYTES);
  printbytes("n", npub, CRYPTO_NPUBBYTES);
  printbytes("a", ad, adlen);
  printbytes("m", m, mlen);

  /* load key and nonce */
  uint64_t K0 = LOADBYTES(k, 8);
  uint64_t K1 = LOADBYTES(k + 8, 8);
  uint64_t N0 = LOADBYTES(npub, 8);
  uint64_t N1 = LOADBYTES(npub + 8, 8);

  /* initialize */
  ascon_state_t s;
  s.x[0] = ASCON_128A_IV;
  s.x[1] = K0;
  s.x[2] = K1;
  s.x[3] = N0;
  s.x[4] = N1;
  printstate("init 1st key xor", &s);
  P12(&s);
  s.x[3] ^= K0;
  s.x[4] ^= K1;
  printstate("init 2nd key xor", &s);

  if (adlen)
  {
    /* full associated data blocks */
    while (adlen >= ASCON_128A_RATE)
    {
      s.x[0] ^= LOADBYTES(ad, 8);
      s.x[1] ^= LOADBYTES(ad + 8, 8);
      printstate("absorb adata", &s);
      P8(&s);
      ad += ASCON_128A_RATE;
      adlen -= ASCON_128A_RATE;
    }
    /* final associated data block */
    if (adlen >= 8)
    {
      s.x[0] ^= LOADBYTES(ad, 8);
      s.x[1] ^= LOADBYTES(ad + 8, adlen - 8);
      s.x[1] ^= PAD(adlen - 8);
    }
    else
    {
      s.x[0] ^= LOADBYTES(ad, adlen);
      s.x[0] ^= PAD(adlen);
    }
    printstate("pad adata", &s);
    P8(&s);
  }
  /* domain separation */
  s.x[4] ^= DSEP();
  printstate("domain separation", &s);

  /* full plaintext blocks */
  while (mlen >= ASCON_128A_RATE)
  {
    s.x[0] ^= LOADBYTES(m, 8);
    s.x[1] ^= LOADBYTES(m + 8, 8);
    STOREBYTES(c, s.x[0], 8);
    STOREBYTES(c + 8, s.x[1], 8);
    printstate("absorb plaintext", &s);
    P8(&s);
    m += ASCON_128A_RATE;
    c += ASCON_128A_RATE;
    mlen -= ASCON_128A_RATE;
  }
  /* final plaintext block */
  if (mlen >= 8)
  {
    s.x[0] ^= LOADBYTES(m, 8);
    s.x[1] ^= LOADBYTES(m + 8, mlen - 8);
    STOREBYTES(c, s.x[0], 8);
    STOREBYTES(c + 8, s.x[1], mlen - 8);
    s.x[1] ^= PAD(mlen - 8);
  }
  else
  {
    s.x[0] ^= LOADBYTES(m, mlen);
    STOREBYTES(c, s.x[0], mlen);
    s.x[0] ^= PAD(mlen);
  }
  m += mlen;
  c += mlen;
  printstate("pad plaintext", &s);

  /* finalize */
  s.x[2] ^= K0;
  s.x[3] ^= K1;
  printstate("final 1st key xor", &s);
  P12(&s);
  s.x[3] ^= K0;
  s.x[4] ^= K1;
  printstate("final 2nd key xor", &s);

  /* get tag */
  STOREBYTES(c, s.x[3], 8);
  STOREBYTES(c + 8, s.x[4], 8);

  /* print output bytes */
  printbytes("c", c - *clen + CRYPTO_ABYTES, *clen - CRYPTO_ABYTES);
  printbytes("t", c, CRYPTO_ABYTES);
  print("\n");

  ascon_clear(&s, sizeof(s));
  ascon_clear(&K0, sizeof(K0)); ascon_clear(&K1, sizeof(K1));
  ascon_clear(&N0, sizeof(N0)); ascon_clear(&N1, sizeof(N1));
  return 0;
}

int crypto_aead_decrypt(unsigned char *m, unsigned long long *mlen,
                        unsigned char *nsec, const unsigned char *c,
                        unsigned long long clen, const unsigned char *ad,
                        unsigned long long adlen, const unsigned char *npub,
                        const unsigned char *k)
{
  (void)nsec;

  unsigned char *const m_out = m;
  *mlen = 0;
  if (clen < CRYPTO_ABYTES)
    return -1;

  /* set plaintext size */
  const unsigned long long plaintext_len = clen - CRYPTO_ABYTES;
  *mlen = plaintext_len;

  /* print input bytes */
  print("decrypt\n");
  printbytes("k", k, CRYPTO_KEYBYTES);
  printbytes("n", npub, CRYPTO_NPUBBYTES);
  printbytes("a", ad, adlen);
  printbytes("c", c, *mlen);
  printbytes("t", c + *mlen, CRYPTO_ABYTES);

  /* load key and nonce */
  uint64_t K0 = LOADBYTES(k, 8);
  uint64_t K1 = LOADBYTES(k + 8, 8);
  uint64_t N0 = LOADBYTES(npub, 8);
  uint64_t N1 = LOADBYTES(npub + 8, 8);

  /* initialize */
  ascon_state_t s;
  s.x[0] = ASCON_128A_IV;
  s.x[1] = K0;
  s.x[2] = K1;
  s.x[3] = N0;
  s.x[4] = N1;
  printstate("init 1st key xor", &s);
  P12(&s);
  s.x[3] ^= K0;
  s.x[4] ^= K1;
  printstate("init 2nd key xor", &s);

  if (adlen)
  {
    /* full associated data blocks */
    while (adlen >= ASCON_128A_RATE)
    {
      s.x[0] ^= LOADBYTES(ad, 8);
      s.x[1] ^= LOADBYTES(ad + 8, 8);
      printstate("absorb adata", &s);
      P8(&s);
      ad += ASCON_128A_RATE;
      adlen -= ASCON_128A_RATE;
    }
    /* final associated data block */
    if (adlen >= 8)
    {
      s.x[0] ^= LOADBYTES(ad, 8);
      s.x[1] ^= LOADBYTES(ad + 8, adlen - 8);
      s.x[1] ^= PAD(adlen - 8);
    }
    else
    {
      s.x[0] ^= LOADBYTES(ad, adlen);
      s.x[0] ^= PAD(adlen);
    }
    printstate("pad adata", &s);
    P8(&s);
  }
  /* domain separation */
  s.x[4] ^= DSEP();
  printstate("domain separation", &s);

  /* full ciphertext blocks */
  clen -= CRYPTO_ABYTES;
  while (clen >= ASCON_128A_RATE)
  {
    uint64_t c0 = LOADBYTES(c, 8);
    uint64_t c1 = LOADBYTES(c + 8, 8);
    STOREBYTES(m, s.x[0] ^ c0, 8);
    STOREBYTES(m + 8, s.x[1] ^ c1, 8);
    s.x[0] = c0;
    s.x[1] = c1;
    printstate("insert ciphertext", &s);
    P8(&s);
    m += ASCON_128A_RATE;
    c += ASCON_128A_RATE;
    clen -= ASCON_128A_RATE;
  }
  /* final ciphertext block */
  if (clen >= 8)
  {
    uint64_t c0 = LOADBYTES(c, 8);
    uint64_t c1 = LOADBYTES(c + 8, clen - 8);
    STOREBYTES(m, s.x[0] ^ c0, 8);
    STOREBYTES(m + 8, s.x[1] ^ c1, clen - 8);
    s.x[0] = c0;
    s.x[1] = CLEARBYTES(s.x[1], clen - 8);
    s.x[1] |= c1;
    s.x[1] ^= PAD(clen - 8);
  }
  else
  {
    uint64_t c0 = LOADBYTES(c, clen);
    STOREBYTES(m, s.x[0] ^ c0, clen);
    s.x[0] = CLEARBYTES(s.x[0], clen);
    s.x[0] |= c0;
    s.x[0] ^= PAD(clen);
  }
  m += clen;
  c += clen;
  printstate("pad ciphertext", &s);

  /* finalize */
  s.x[2] ^= K0;
  s.x[3] ^= K1;
  printstate("final 1st key xor", &s);
  P12(&s);
  s.x[3] ^= K0;
  s.x[4] ^= K1;
  printstate("final 2nd key xor", &s);

  /* get tag */
  uint8_t t[16];
  STOREBYTES(t, s.x[3], 8);
  STOREBYTES(t + 8, s.x[4], 8);

  /* verify should be constant time, check compiler output */
  int i;
  int result = 0;
  for (i = 0; i < CRYPTO_ABYTES; ++i)
    result |= c[i] ^ t[i];
  result = (((result - 1) >> 8) & 1) - 1;

  ascon_clear(&s, sizeof(s));
  ascon_clear(&K0, sizeof(K0)); ascon_clear(&K1, sizeof(K1));
  ascon_clear(&N0, sizeof(N0)); ascon_clear(&N1, sizeof(N1));
  ascon_clear(t, sizeof(t));

  if (result != 0)
  {
    /* Clear only the candidate plaintext; volatile stores retain the wipe. */
    volatile unsigned char *p = m_out;
    unsigned long long remaining = plaintext_len;
    while (remaining != 0)
    {
      *p++ = 0;
      --remaining;
    }
    *mlen = 0;
    return result;
  }

  /* print output bytes */
  printbytes("m", m - *mlen, *mlen);
  print("\n");

  return result;
}
