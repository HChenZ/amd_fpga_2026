# Technical report

final_report.pdf is the current compiled paper. Editable files are under latex/.
Compile main.tex with XeLaTeX/latexmk or Tectonic. The report verifier requires the full repository and
restored original record layout; review scripts retain that original layout and may need explicit path restoration.
Standalone LaTeX compilation is not a new evidence/board verification.
Screenshot pixels and third-party notices are preserved. Original test/implementation records are not included.

Code blocks require DejaVu Sans Mono (validated with 2.37); without it the font may silently fall back and change line wrapping.
